#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class Airplane {
  private:
    string model;
    int altitude;
    int minAltitude;
    int maxAltitude;
  public:
    Airplane();
    Airplane(string model, int altitude, int minAltitude, int maxAltitude);
    void display();
    void setAltitude();
    bool crash (Airplane);
};

Airplane::Airplane() {
  model = " ";
  altitude = 0;
  maxAltitude = 0;
  minAltitude =  0;
}

Airplane::Airplane(string m, int alt, int min, int max) {
  model = m;
  altitude = alt;
  maxAltitude = max;
  minAltitude = min;
  alt = max - min;
}

void Airplane::display() {
  cout << "Model: " << model << endl;
  cout << "Altitude: " << altitude << endl;
  cout << "Minimum Altitude: " << minAltitude << endl;
  cout << "Maximum Altitude: " << maxAltitude << endl;
}
    
void Airplane::setAltitude() {
  altitude = (rand() % (maxAltitude - minAltitude + 1) + minAltitude);
}

bool Airplane::crash (Airplane a) {
  if (abs(altitude - a.altitude) <= 200) {
    return true;
  }
  else {
      return false;
  }
}

int main() {
  Airplane one("F22", 0, 1000, 2000);
  Airplane two("F18", 0, 2000, 5000);
  bool crash;
  int planeCrash = 0;
  srand(time(NULL));
  for (int i = 0; i < 1000; i++) {
    one.setAltitude();
    two.setAltitude();
  if((one.crash(two) == true) || (two.crash(one) == true)) {
    cout << "Number of times it loops: " << i << endl;
    cout << "It crashed!" << endl;
    cout << planeCrash;
    one.display();
    two.display();
    planeCrash++;
  } //else {
    //cout << "The planes made it to their destination!\n";
  //}
  }
  cout << "Number of crashes: " << planeCrash << endl;
  double percentage = (planeCrash / 1000.0) * 100;
  cout << "Percentage of crashes: " << percentage << "%";
}