//Joon Im
//Marie Payad
//Demo time:8:57

#include<iostream>
#include <iomanip>
using namespace std;

class Student
{
  private:
  string name;
  int score;
  char grade;
  public:
  Student();
  Student(string nm, int sc);
  void print();
};

// Default constructor
Student::Student()
{
  name = "empty";
  score = 0;
  grade = '0';
}

// Parameter Constructor
Student::Student(string nm, int sc)
:name (nm), score (sc)
{
  name = nm;
  score = sc;
  //Determine the grade
  if(sc >= 90 && sc <= 100)
  {
    grade = 'A';
  } else if (sc >= 80 && sc <= 89)
  {
    grade = 'B';
  } else if (sc >= 70 && sc <= 79)
  {
    grade = 'C';
  } else if (sc >= 60 && sc <= 69)
  {
    grade = 'D';
  } else if (sc >= 0 && sc <= 59)
  {
    grade = 'F';
  }
}

// Print member function
void Student::print()
{
cout << setw (6) << left << name;
cout << setw (4) << right << score;
cout << setw (4) << right << grade;
cout << endl;
}

int main ()
{
// Declaration of an array of using default constructors
Student students [5];

// Instantiation of five objects using parameter constructors
students[0] = Student("Tom", 85);
students[1] = Student("Alice", 71);
students[2] = Student("Jack", 93);
students[3] = Student("Mary", 65);
students[4] = Student("Sue", 54);

// Printing students name, score, and grade
for(int i = 0; i < 5; i++)
{
  students[i].print();
}

return 0;
}