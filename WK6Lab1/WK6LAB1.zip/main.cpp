//Marie Papayad
//Joon Im
//Demo:
#include <iostream>

using namespace std;

int main() {
  long value1 = 300000, value2;
  long *longPtr;
  longPtr = &value1;
  cout << "Display the value of the object pointed to by longPtr: " << *longPtr << endl;
  value2 = *longPtr;
  cout << endl;
  cout << "Display the value of value2: " << value2 << endl;
  cout << endl;
  cout << "Display the address of value1: " << &value1 << endl;
  cout << endl;
  cout << "Display the address stored in longPtr: " << longPtr; // the address displayed is the same as value1
}

